package com.example.aplikasi_matematika

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
